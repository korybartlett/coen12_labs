#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include "tree.h"
#include "pack.h"

void insert(struct tree *);
struct tree *delete(void);
void encoding(struct tree *);

int counter = 0;
int i;
struct tree *leaves[257];
struct tree *heap[257];

int main(int argc, char *argv[])
{
	FILE *fp;
	int c, new;
	int count[257];
    struct tree *FirstMin, *SecondMin, *NewMin;
	
	fp = fopen(argv[1], "rb");
	if(fp == NULL)
	{
		printf("File could not be opened\n");
		return -1;
	}
	
	for(i=0; i<257; i++)
	{
		leaves[i] = NULL;
	}
	
	for(i=0;i<257;i++)
	{
		count[i] = 0;
	}

	while((c=getc(fp))!=EOF)
	{
		count[c]++;
	}

	for(i=0;i<257;i++)
	{
		if(count[i]>0)
		{
			leaves[i] = createTree(count[i], NULL, NULL);
			insert(leaves[i]);
		}
	}
	
	leaves[256] = createTree(0, NULL, NULL);
	insert(leaves[256]);

	while(counter!=1)
	{
		FirstMin = delete();
		SecondMin = delete();
		new = getData(FirstMin) + getData(SecondMin);
		NewMin = createTree(new, FirstMin, SecondMin);
		insert(NewMin);
	}

	for(i=0;i<257;i++)
	{
		if(leaves[i]!= NULL)
		{
			if(isprint(i))
			{
				printf("'%c': %d ",i, getData(leaves[i]));
				encoding(leaves[i]);
				printf("\n");
			}

			else
			{
				printf("%03o: %d ",i, getData(leaves[i]));
				encoding(leaves[i]);
				printf("\n");
			}
		}
	}

	pack(argv[1], argv[2], leaves);
}

void insert(struct tree *leaf)
{
    int HeapDepth = counter;
    int ParentDepth = ((HeapDepth-1)/2);
    while(HeapDepth!=0 && getData(heap[ParentDepth])>getData(leaf))
    {
		heap[HeapDepth] = heap[ParentDepth];
		HeapDepth = ParentDepth;
		ParentDepth = ((HeapDepth-1)/2);
	}
	heap[HeapDepth]=leaf;
	counter++;
}

struct tree *delete(void)
{
    int i, child;
    i = 0;
    struct tree *min = heap[0];
    
    struct tree *StartUp = heap[counter -1];
    
    while((2*i +1) < counter)
    {
		child = 2*i + 1;
		
		if(2*i+2 < counter && getData(heap[2*i+1]) > getData(heap[2*i+2]))
		{
			child = 2*i +2;
		}

		if(getData(StartUp) > getData(heap[child]))
		{
			heap[i] = heap[child];
			i = child;
		}
		else
		{
			break;
		}
    }

	heap[i] = StartUp;
	counter--;
	return min;

}

void encoding(struct tree *leaves)
{
	struct tree *parent;
	parent = getParent(leaves);
	if(parent != NULL)
	{	
		if(getLeft(parent) == leaves)
		{
			encoding(parent);
			printf("0");
			return;
		}
		else
		{
			encoding(parent);
			printf("1");
			return;
		}
	}
	else
	{
		return;
	}
}
