#include<stdio.h>
#include<stdlib.h>
#include<assert.h>
#include "tree.h"

void detach(struct tree *branch);

struct tree
{
	int data;
	struct tree *left, *right, *parent;
};

struct tree *createTree(int data, struct tree *left, struct tree *right)
{
	struct tree *root;
	root = malloc(sizeof(struct tree));
	assert(root!=NULL);
	root->data = data;
	root->right = right;
	root->left = left;
	root->parent = NULL;
	
	if(root->left != NULL)
	{
		detach(root->left);
		left->parent = root;
	}

	if(root->right != NULL)
	{
		detach(root->right);
		right->parent = root;
	}

	return root;
}

void destroyTree(struct tree *root)
{
	if (root != NULL)
	{
		destroyTree(root->left);
		destroyTree(root->right);
		free(root);
	}
	return;
}

int getData(struct tree *root)
{
	assert(root!=NULL);
	return root->data;
}

struct tree *getLeft(struct tree *root)
{
	assert(root!=NULL);
	return root->left;
}

struct tree *getRight(struct tree *root)
{
	assert(root!=NULL);
	return root->right;
}

struct tree *getParent(struct tree *root)
{
	assert(root!=NULL);
	return root->parent; 
}

void setLeft(struct tree *root, struct tree *left)
{
	assert(root != NULL && left != NULL);
	if(root->left!=NULL)
	{
		root->left->parent = NULL; 
	}
	root->left = left;
	if(left!=NULL)
	{
	detach(left);
	left->parent = root;
	}
}

void setRight(struct tree *root, struct tree *right)
{
	assert(root != NULL && right != NULL);
	if(root->right!=NULL)
	{	
		root->right->parent = NULL;
	}
	root->right = right;
	if(right!=NULL)
	{
		detach(right);
		right->parent=root;
	}
}

void detach(struct tree *root)
{
	assert(root!=NULL);
	if(root->parent == NULL)
	{
		return;
	}
	
	if(root->parent->left!=NULL)
	{
		root->parent->left = NULL;
	}

	if(root->parent->right!= NULL)
	{
		root->parent->right = NULL;
	}
}
